
<?php $__env->startSection('title' , 'status page'); ?>

<?php $__env->startSection('content'); ?>


<section class="px-2 md:px-0 tails-selected-element" >
  <div class="container items-center max-w-6xl p-8 mx-auto relative -mt-12  bg-white shadow-lg rounded-xl z-[60]">
    <div class="flex flex-wrap items-center sm:-mx-3">
      <div class="w-full">
        <div class="w-full pb-6 space-y-6 md:space-y-4 lg:space-y-8 xl:space-y-9 sm:pr-5 lg:pr-0 md:pb-0">
          <h2 class="text-3xl tracking-tight text-gray-900 -mb-4 font-bold flex items-center">
            <span class="bg-red-500 rounded-full p-1 shadow-md ml-3"><i class="text-white" data-feather="x"></i></span>
            <p class="block xl:inline">برخی از سرویس ها دچار<span class="block text-red-600 xl:inline " data-primary="indigo-600"> اختلال </span> هستند</p>
          </h2>




          <div class="container mx-auto px-20">

            <div style='background-color:rgb(255, 255, 255)'>
            <div class="relative px-4 mx-auto max-w-7xl sm:px-6 lg:px-8" style="cursor: auto;">
              <div class="max-w-lg mx-auto overflow-hidden rounded-lg shadow-lg lg:max-w-none lg:flex">
                <div class="flex-1 px-6 py-8 bg-white lg:p-12" style="cursor: auto;">
                  <h3 class="text-2xl font-extrabold text-gray-900 sm:text-3xl" style="cursor: auto;">Premium Membership Plan</h3>
                  <p class="mt-6 text-base text-gray-500">Metus potenti velit sollicitudin porttitor magnis elit lacinia tempor varius, ut cras orci vitae parturient id nisi vulputate consectetur, primis venenatis cursus tristique malesuada viverra congue risus. Class dui ut ullamcorper ultrices arcu ad varius adipiscing, aliquet imperdiet hendrerit orci fusce ante felis, mi mus vel finibus viverra nibh taciti.</p>
                  <div class="mt-8">
                    <div class="flex items-center">
                      <h4 class="flex-shrink-0 pr-4 text-sm font-semibold tracking-wider text-indigo-600 uppercase bg-white">What's included</h4>
                      <div class="flex-1 border-t-2 border-gray-200"></div>
                    </div>
                    <ul class="mt-8 space-y-5 lg:space-y-0 lg:grid lg:grid-cols-2 lg:gap-x-8 lg:gap-y-5">
                      <li class="flex items-start lg:col-span-1">
                        <div class="flex-shrink-0">
                          <svg class="w-5 h-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                        </div>
                        <p class="ml-3 text-sm text-gray-700">Private repository access</p>
                      </li>
                      <li class="flex items-start lg:col-span-1">
                        <div class="flex-shrink-0">
                          <svg class="w-5 h-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                        </div>
                        <p class="ml-3 text-sm text-gray-700">Extensive documentation</p>
                      </li>
                      <li class="flex items-start lg:col-span-1">
                        <div class="flex-shrink-0">
                          <svg class="w-5 h-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                        </div>
                        <p class="ml-3 text-sm text-gray-700">Access to new updates</p>
                      </li>
                      <li class="flex items-start lg:col-span-1">
                        <div class="flex-shrink-0">
                          <svg class="w-5 h-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                        </div>
                        <p class="ml-3 text-sm text-gray-700">Personal license</p>
                      </li>
                      <li class="flex items-start lg:col-span-1">
                        <div class="flex-shrink-0">
                          <svg class="w-5 h-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                        </div>
                        <p class="ml-3 text-sm text-gray-700">Additional SaaS resources</p>
                      </li>
                      <li class="flex items-start lg:col-span-1">
                        <div class="flex-shrink-0">
                          <svg class="w-5 h-5 text-green-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                            <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
                          </svg>
                        </div>
                        <p class="ml-3 text-sm text-gray-700">Email support</p>
                      </li>
                    </ul>
                  </div>
                </div>
                <div class="px-6 py-8 text-center bg-gray-50 lg:flex-shrink-0 lg:flex lg:flex-col lg:justify-center lg:p-12" style="cursor: auto;">
                  <p class="mt-4 text-gray-500" style="text-decoration-line:line-through;text-decoration-style:solid">$299 / year</p>
                  <div class="flex items-center justify-center mt-4 text-5xl font-extrabold text-gray-900">
                    <span>$149</span>
                    <span class="ml-3 text-xl font-medium text-gray-500">/ year</span>
                  </div>
                  <div class="mt-6">
                    <div class="rounded-md shadow">
                      <a href="https://stackdiary.com/" class="flex items-center justify-center w-full px-5 py-3 text-base font-medium text-white bg-gray-800 border border-transparent rounded-md hover:bg-gray-900" target="_blank">Get Access</a>
                    </div>
                  </div>
                  <div class="mt-4 text-sm">
                    <a href="https://stackdiary.com/" class="font-medium text-gray-700 hover:text-gray-900" target="_blank">Or pick a 
                      <span class="font-bold">lifetime</span> plan
                    </a>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>







        </div>
      </div>



    </div>
  </div>

  <input type="checkbox" id="my-modal-3" class="modal-toggle" />
        <div class="modal">
          <div class="modal-box relative">
            <label for="my-modal-3" class="btn btn-sm bg-gray-300 btn-circle border-0 absolute left-2 top-2">✕</label>
            <h3 class="text-lg font-bold text-blue-600">گزارش مشکل و اختلال سرویس</h3>
            <p class="py-4">در صورتی که وب سایت و یا هاست شما دچار خطا میباشد می توانید این مورد را گزارش دهید !</p>
            <input class="w-full border-2 p-2 rounded-lg" placeholder="آدرس سایت و یا آیپی سرور "  type="text">
            <input class="w-full border-2 p-2 rounded-lg mt-2" placeholder="آدرس ایمیل"  type="email">
            <div class="text-left mt-2"><button class="btn bg-blue-600 w-20">ارسال</button></div>
          </div>
        </div>
</section>



<section class="px-2 md:px-0 tails-selected-element  my-12" >
  <div class="container items-center max-w-6xl pb-4 mx-auto relative">
      <h2 class="text-2xl tracking-tight text-gray-900 font-bold">
            <span class="block xl:inline">گزارش وضعیت سرورها</span>
      </h2>
  </div>

  <div class="container items-center max-w-6xl p-8 mx-auto relative  bg-white shadow-lg rounded-xl z-[60]">
    <div class="flex flex-wrap items-center sm:-mx-3">
      <div class="w-full">
        <div class="w-full pb-6 space-y-6 md:space-y-4 lg:space-y-8 xl:space-y-9 sm:pr-5 lg:pr-0 md:pb-0">
          <div class="grid gap-10 sm:gap-4  grid-cols-2 sm:grid-cols-4 divide-x divide-x-reverse ">
            <div class="text-center flex flex-col text-2xl">99.998% <span class="text-sm text-gray-400">24 ساعت گذشته</span></div>
            <div class="text-center flex flex-col text-2xl">99.998% <span class="text-sm text-gray-400">7 روز گذشته</span></div>
            <div class="text-center flex flex-col text-2xl">100.00% <span class="text-sm text-gray-400">30 روز گذشته</span></div>
            <div class="text-center flex flex-col text-2xl">100.00% <span class="text-sm text-gray-400">90 روز گذشته</span></div>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>

<section class="px-2 md:px-0 tails-selected-element  my-12" >
  <div class="container items-center max-w-6xl pb-4 mx-auto relative">
      <h2 class="text-2xl tracking-tight text-gray-900 font-bold">
            <p class="block xl:inline"> پایداری سرورها <span class="text-sm">90 روز گذشته</span></p>
      </h2>
  </div>


  <div class="container items-center max-w-6xl pt-16 px-8 mx-auto relative  bg-white shadow-lg rounded-xl z-[60]">
    <div class="absolute w-full right-0 top-0 py-3 px-5  bg-gray-100 rounded-t-xl flex justify-between">
      <div> راهنمای وضعیت سرویس ها </div>
      <div class="flex space-x-4 space-x-reverse">
        <div class="flex items-center text-green-600"><i class="w-4 ml-1" data-feather="check-circle"></i> آنلاین  </div>
        <div class="flex items-center text-orange-600"><i class="w-4 ml-1" data-feather="minus-circle"></i> اختلال موقت </div>
        <div class="flex items-center text-gray-500"><i class="w-4 ml-1" data-feather="alert-circle"></i> بدون رکورد  </div>
      </div>
    </div>
    <div class="flex flex-wrap items-center sm:-mx-3">
      <div class="w-full">
        <div class="w-full pb-6 space-y-6 md:space-y-4 lg:space-y-8 xl:space-y-9 sm:pr-5 lg:pr-0 md:pb-0">


        <div class="container">
              <div class="uptime-body">
                <div class="uptime-card align-items-stretch">                
                  <div class="card border-0 mb-4">
                    <div class="card-body p-4">

                        <a class="flex items-center" href="/server/details">
                            <h5  class="title text-base font-bold ml-2"></h5>
                            <span class="text-sm">(جزئیات)</span>
                          </a>                  

                      <div class="flex items-center ">

                        <div class="col uptime"></div>
                        <span class="uptime-percent text-green-500 mr-5"></span>

                        <div class="pl-2 mr-auto flex items-center space-x-2 space-x-reverse">
                          <span class="flex h-3 w-3 relative">
                              <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                              <span class="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                            </span>
                            <span class="float-right pid text-green-500"></span>
                        </div>
                      </div>

                    </div>
                  </div>    
                </div>
              </div>     
      </div>


        </div>
      </div>

    </div>
  </div>
</section>

<script>
  function rInt(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function pStat(e){
  var r = rInt(0, 99);
  let monthsArray = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  var currentdate = new Date(); 
  var datetime =  monthsArray[currentdate.getMonth()] + " "  
                  + currentdate.getDate()  + "," 
                  + currentdate.getFullYear() ;
  switch(true){
    case r == 0:
      $(e).append('<div class="uptime-marker nodata tooltip" data-tip="' + datetime + ' \n '  + '%' + r + ' "></div>');
      break;

    case r <= 10 && r > 0:
      $(e).append('<div class="uptime-marker down tooltip " data-tip="' + datetime + ' \n '  + '%' + r + ' " ></div>');
      break;

    case r > 10 && r < 50:
      $(e).append('<div class="uptime-marker med tooltip" data-tip="' + datetime + ' \n '  + '%' + r + ' "></div>');
          break;

    case r >= 50:
      $(e).append('<div class="uptime-marker up tooltip" data-tip="' + datetime + ' \n '  + '%' + r + ' "></div>');
      break;


  }
}

$(document).ready(function(){

  for(i=0;i<3;i++){
    var c = $(".uptime-card").first().clone();
    $('.title', c).text('سرور تست');
    $('.pid', c).text('آنلاین');
    $('.uptime-percent', c).text('100.00%');
    c.appendTo('.uptime-body');
  }
  $(".uptime-card").first().css("display", "none");

  $(".uptime").each(function(index) {
    // var r = rInt(1, 4);
    var day = 90;
    for(i=0;i<day;i++)
    {
      pStat(this);

    } 
  });
});
</script>

  <?php $__env->startSection('footer-scripts'); ?>

  
    
  <?php $__env->stopSection(); ?>

  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\server-status\resources\views/down.blade.php ENDPATH**/ ?>