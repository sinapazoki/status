
<!DOCTYPE html>
<html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <meta name="_token" content="<?php echo e(csrf_token()); ?>">
        <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?> 

        <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Saira:wght@500&display=swap" rel="stylesheet">
<link href="http://fonts.cdnfonts.com/css/iranyekan" rel="stylesheet">
        <?php $__env->startSection('header-scripts'); ?>

        <?php echo $__env->yieldSection(); ?>
        <title>  <?php echo $__env->yieldContent('title'); ?></title>

   </head>


        
        <body class="main font-iranyekan bg-gray-50 flex flex-col justify-between" >

        <nav class="relative z-50 h-40 select-none tails-selected-element bg-blue-600" x-data="{ showMenu: false }">
            <div class="container relative flex flex-wrap items-center justify-between h-40 pb-10 mx-auto overflow-hidden font-medium  md:overflow-visible lg:justify-center sm:px-4 md:px-2 lg:px-0">
                <div class="top-0 left-0 items-start hidden w-full h-full p-4 text-sm bg-blue-900 bg-opacity-50 md:items-center md:w-3/4 md:absolute lg:text-base md:bg-transparent md:p-0 md:relative md:flex" :class="{'flex fixed': showMenu, 'hidden': !showMenu }">
                    <div class="flex-col w-full h-auto overflow-hidden bg-white rounded-lg md:bg-transparent md:overflow-visible md:rounded-none md:relative md:flex md:flex-row">
                        <a href="#_" class="inline-flex items-center block w-auto h-16 px-6 text-xl font-black leading-none text-gray-900 md:hidden">tails<span class="text-indigo-600">.</span></a>
                        <div class="flex flex-col justify-start w-full space-x-6 text-center lg:space-x-8 md:w-2/3 md:mt-0 md:flex-row md:items-center">

                            <div class="flex items-center space-x-4 space-x-reverse">
                                <div class="bg-white p-4 rounded-xl shadow-md">
                                    <i class="text-blue-800" data-feather="server"></i>
                                </div>

                                <div class="text-white flex items-start flex-col">
                                    <h3 class="text-2xl pb-3">وضعیت سرورها</h3>
                                    <span class="text-sm text-gray-300">Last updated 10:06:25 PM | Next update in 16 sec</span>
                                </div>
                            </div>

                        </div>

                        <div class="flex items-end justify-end w-full pt-4 md:w-1/3 md:flex-col md:py-0">
                            <div class="flex items-center">
                                <h1 class="w-full px-3 py-2 mr-0 text-3xl text-white md:mr-2 lg:mr-3 md:w-auto">HIGHHOST</h1>
                                <span class="flex h-5 w-5 relative">
                                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-sky-400 opacity-75"></span>
                                <span class="relative inline-flex rounded-full h-5 w-5 bg-sky-500"></span>
                                </span>
                            </div>

                            <div>
                                <a href="https://highhost.org/" class="flex text-white text-sm items-center"> بازگشت به سایت <i class="w-4 mr-2 text-white" data-feather="arrow-left"></i></a>
                            </div>
                            
                        </div>

                    </div>
                </div>
                <div @click="showMenu = !showMenu" class="absolute right-0 flex flex-col items-center items-end justify-center w-10 h-10 bg-white rounded-full cursor-pointer md:hidden hover:bg-gray-100">
                    <svg class="w-6 h-6 text-gray-700" x-show="!showMenu" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24" stroke="currentColor"><path d="M4 6h16M4 12h16M4 18h16"></path></svg>
                    <svg class="w-6 h-6 text-gray-700" x-show="showMenu" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" style="display: none;"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                </div>
            </div>
        </nav>



              <main class="mb-auto">

                    <?php $__env->startSection('content'); ?>

                    <?php echo $__env->yieldSection(); ?>

              </main>
              

          <script>
            feather.replace()
          </script>
         


            <?php $__env->startSection('footer-scripts'); ?>

            <?php echo $__env->yieldSection(); ?>





        </body>
</html>
<?php /**PATH C:\wamp64\www\server-status\resources\views/layouts/master.blade.php ENDPATH**/ ?>